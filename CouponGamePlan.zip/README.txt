Coupon Game Plan

Files:
- index.html
- styles.css
- app.js

How to deploy:
1. Unzip the folder.
2. Upload all three files to Netlify, Cloudflare Pages, GitHub Pages, or another static host.
3. Make sure index.html is at the site root.

Current data:
The website currently contains demo product prices so the shopping optimizer works immediately.
For production use, replace the demo product array in app.js with live price/coupon data from your preferred retailer data source.

Main workflow:
Store -> Budget -> Needs -> Build My Best Cart
